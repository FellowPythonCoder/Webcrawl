/* english.h — cheap, allocation-free "is this page English?" filter.
 *
 * Layers (cheapest first, each one can reject):
 *   1. TLD allow-list + no punycode (xn--)      -> en_domain_ok()   (before any DNS/connect)
 *   2. Content-Type must be HTML/text            -> english_ok()
 *   3. Content-Language header must be en*       -> english_ok()
 *   4. <html lang="..."> must be en*             -> english_ok()
 *   5. Visible text: foreign-script ratio + English stop-word density
 *   6. Title must not be mostly non-English letters
 */
#ifndef ENGLISH_H
#define ENGLISH_H

#include <stdlib.h>
#include <string.h>
#include <strings.h>

static const char *EN_TLDS[] = {
    "com",     "net",     "org",    "edu",      "gov",     "mil",    "int",
    "io",      "co",      "info",   "biz",      "us",      "uk",     "ca",
    "au",      "nz",      "ie",     "in",       "sg",      "za",     "ph",
    "me",      "tv",      "app",    "dev",      "ai",      "tech",   "online",
    "site",    "store",   "blog",   "news",     "live",    "world",  "today",
    "digital", "cloud",   "space",  "page",     "zone",    "club",   "shop",
    "art",     "fun",     "xyz",    "one",      "pro",     "mobi",   "name",
    "design",  "media",   "studio", "agency",   "press",   "works",  "team",
    "systems", "network", "group",  "company",  "services","academy","school",
    "science", "health",  "email",  "website",  "review",  "guru",   "life",
    "games",   "game",    "run",    "data"};
#define EN_TLDS_N (sizeof(EN_TLDS) / sizeof(EN_TLDS[0]))

/* Domain (already lower-case, no port) has an English-friendly TLD and is not
 * an internationalised (punycode) name. */
static int en_domain_ok(const char *d) {
  const char *dot = strrchr(d, '.');
  if (!dot || !dot[1])
    return 0;
  if (strstr(d, "xn--"))
    return 0;
  const char *tld = dot + 1;
  for (size_t i = 0; i < EN_TLDS_N; i++)
    if (strcmp(tld, EN_TLDS[i]) == 0)
      return 1;
  return 0;
}

/* ---- tiny helpers ---- */
static int en_lower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

static int en_find(const char *hay, int len, const char *needle) {
  int nl = (int)strlen(needle);
  for (int i = 0; i + nl <= len; i++)
    if (strncasecmp(hay + i, needle, (size_t)nl) == 0)
      return i;
  return -1;
}

/* offset just past the blank line that ends the HTTP headers, or -1 */
static int en_header_end(const char *buf, int len) {
  for (int i = 0; i + 3 < len; i++)
    if (buf[i] == '\r' && buf[i + 1] == '\n' && buf[i + 2] == '\r' &&
        buf[i + 3] == '\n')
      return i + 4;
  return -1;
}

/* copy header value (trimmed) into out; returns 1 if the header exists */
static int en_header_value(const char *buf, int hlen, const char *name,
                           char *out, int cap) {
  int nl = (int)strlen(name);
  int i = 0;
  while (i < hlen) {
    int e = i;
    while (e < hlen && buf[e] != '\n')
      e++;
    if (e - i > nl + 1 && strncasecmp(buf + i, name, (size_t)nl) == 0 &&
        buf[i + nl] == ':') {
      int p = i + nl + 1;
      while (p < e && (buf[p] == ' ' || buf[p] == '\t'))
        p++;
      int n = 0;
      while (p < e && buf[p] != '\r' && n < cap - 1)
        out[n++] = (char)en_lower((unsigned char)buf[p++]);
      out[n] = '\0';
      return 1;
    }
    i = e + 1;
  }
  return 0;
}

/* value starts with "en" as a whole primary language subtag: en, en-US, en_GB */
static int en_lang_is_english(const char *v) {
  while (*v == ' ' || *v == '"' || *v == '\'')
    v++;
  if (en_lower((unsigned char)v[0]) != 'e' || en_lower((unsigned char)v[1]) != 'n')
    return 0;
  char c = v[2];
  return c == '\0' || c == '-' || c == '_' || c == ',' || c == ';' ||
         c == ' ' || c == '"' || c == '\'';
}

/* returns 1 = declared, fills out; 0 = no lang attribute on <html> */
static int en_html_lang(const char *body, int len, char *out, int cap) {
  int scan = len < 4096 ? len : 4096;
  int h = en_find(body, scan, "<html");
  if (h < 0)
    return 0;
  int end = h;
  while (end < scan && body[end] != '>')
    end++;
  int l = en_find(body + h, end - h, "lang=");
  if (l < 0)
    return 0;
  int p = h + l + 5;
  if (p < end && (body[p] == '"' || body[p] == '\''))
    p++;
  int n = 0;
  while (p < end && body[p] != '"' && body[p] != '\'' && body[p] != ' ' &&
         n < cap - 1)
    out[n++] = (char)en_lower((unsigned char)body[p++]);
  out[n] = '\0';
  return n > 0;
}

static int en_is_stopword(const char *w, int n) {
  static const char *SW[] = {
      "the",  "and",  "of",   "to",   "in",   "is",   "for",  "with", "that",
      "this", "on",   "are",  "as",   "be",   "by",   "at",   "or",   "from",
      "you",  "your", "we",   "our",  "it",   "not",  "have", "all",  "can",
      "will", "about","more", "new",  "was",  "an",   "has",  "but",  "they",
      "their","home", "contact","which","if",  "how",  "what", "when", "who"};
  if (n < 2 || n > 7)
    return 0;
  for (size_t i = 0; i < sizeof(SW) / sizeof(SW[0]); i++)
    if ((int)strlen(SW[i]) == n && memcmp(SW[i], w, (size_t)n) == 0)
      return 1;
  return 0;
}

typedef struct {
  int words;    /* ASCII words seen                       */
  int stop;     /* of which English stop-words            */
  int ascii;    /* ASCII letters                          */
  int foreign;  /* UTF-8 lead bytes of non-Latin/accented */
} EnScore;

/* One pass over visible text (skips <script>/<style>/comments/entities).
 * UTF-8 leads 0xC2 (Latin-1 punctuation) and 0xE2 (general punctuation,
 * symbols) are treated as neutral so quotes, dashes, (c) and TM don't count
 * against an English page. */
static void en_score_text(const char *s, int len, EnScore *sc) {
  memset(sc, 0, sizeof *sc);
  char w[16];
  int wl = 0;
  for (int i = 0; i < len; i++) {
    unsigned char c = (unsigned char)s[i];
    if (c == '<') {
      int rest = len - i;
      if (rest >= 4 && memcmp(s + i, "<!--", 4) == 0) {
        int e = en_find(s + i + 4, rest - 4, "-->");
        i = (e < 0) ? len : i + 4 + e + 2;
      } else {
        char nm[8];
        int k = 0, j = i + 1;
        while (j < len && k < 7 && ((s[j] >= 'a' && s[j] <= 'z') ||
                                    (s[j] >= 'A' && s[j] <= 'Z'))) {
          nm[k++] = (char)en_lower((unsigned char)s[j]);
          j++;
        }
        nm[k] = '\0';
        int skip_to_close = (strcmp(nm, "script") == 0 || strcmp(nm, "style") == 0);
        int e = 0;
        if (skip_to_close) {
          char close[16];
          close[0] = '<';
          close[1] = '/';
          memcpy(close + 2, nm, (size_t)k + 1);
          e = en_find(s + i, rest, close);
          if (e < 0) {
            i = len;
            e = 0;
          } else {
            int g = i + e;
            while (g < len && s[g] != '>')
              g++;
            i = g;
          }
        } else {
          while (i < len && s[i] != '>')
            i++;
        }
      }
      goto word_break;
    }
    if (c == '&') {
      int j = i + 1;
      while (j < len && j - i < 10 && s[j] != ';' && s[j] != ' ')
        j++;
      if (j < len && s[j] == ';')
        i = j;
      goto word_break;
    }
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
      sc->ascii++;
      if (wl < 15)
        w[wl++] = (char)en_lower(c);
      else
        wl = 16; /* overlong: not a stop-word */
      continue;
    }
    if (c >= 0xC0) { /* UTF-8 lead byte */
      if (c != 0xC2 && c != 0xE2)
        sc->foreign++;
      goto word_break;
    }
    if (c >= 0x80) /* continuation byte */
      goto word_break;
  word_break:
    if (wl > 0) {
      sc->words++;
      if (wl <= 7 && en_is_stopword(w, wl))
        sc->stop++;
      wl = 0;
    }
  }
  if (wl > 0) {
    sc->words++;
    if (wl <= 7 && en_is_stopword(w, wl))
      sc->stop++;
  }
}

/* Full-response check. buf = raw HTTP response (headers + body), title = the
 * extracted <title> text. Returns 1 if the page looks English. */
static int english_ok(const char *buf, int len, const char *title) {
  int hend = en_header_end(buf, len);
  if (hend < 0)
    return 0;
  char v[64];

  if (en_header_value(buf, hend, "content-type", v, sizeof v) &&
      !strstr(v, "html") && !strstr(v, "text/plain"))
    return 0;
  if (en_header_value(buf, hend, "content-language", v, sizeof v) &&
      !en_lang_is_english(v))
    return 0;

  const char *body = buf + hend;
  int blen = len - hend;

  int declared_en = 0;
  if (en_html_lang(body, blen, v, sizeof v)) {
    if (!en_lang_is_english(v))
      return 0;
    declared_en = 1;
  }

  /* title: reject if a meaningful share is non-English script/accents */
  {
    EnScore ts;
    en_score_text(title, (int)strlen(title), &ts);
    if (ts.foreign > 0 && ts.foreign * 100 > 20 * (ts.ascii + ts.foreign))
      return 0;
    if (ts.ascii + ts.foreign == 0) /* title has no letters at all */
      return 0;
  }

  EnScore sc;
  en_score_text(body, blen, &sc);

  /* foreign-script text (CJK, Cyrillic, Arabic, accented Latin) */
  if (sc.foreign * 100 > 12 * (sc.ascii + sc.foreign))
    return 0;

  if (sc.words >= 40) {
    int need = declared_en ? 6 : 10; /* min stop-word % of words */
    if (sc.stop * 100 < need * sc.words || sc.stop < 5)
      return 0;
    return 1;
  }
  /* thin page (mostly scripts/markup): trust an en declaration, else demand
   * some positive English evidence */
  if (declared_en)
    return 1;
  return sc.stop >= 2 && sc.foreign == 0;
}

#endif
