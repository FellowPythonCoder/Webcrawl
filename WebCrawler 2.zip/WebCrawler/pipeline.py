#!/usr/bin/env python3
"""Headless mode: runs ./crawler_engine and stores results in crawler.db (same DB as the app).
Uses constant memory (no in-RAM site lists). Ctrl+C stops and saves. Export with: python3 -c "import db; db.export_a_to_z()"
"""
import os
import subprocess
import sys
import time

import db

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(APP_DIR, "crawler_engine")
TARGET_LIMIT = 100_000_000
BATCH = 1000


def main():
    db.init_db()
    if not os.path.exists(ENGINE):
        print("crawler_engine missing. Build: clang -O3 -pthread crawler.c -o crawler_engine")
        sys.exit(1)
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        want = 20000 if hard == resource.RLIM_INFINITY else min(hard, 20000)
        if want > soft:
            resource.setrlimit(resource.RLIMIT_NOFILE, (want, hard))
    except Exception:
        pass
    proc = subprocess.Popen([ENGINE], stdout=subprocess.PIPE, text=True, errors="replace",
                            bufsize=1 << 20, cwd=APP_DIR)
    batch, total, new, t0, last_ui = [], db.get_total_in_db(), 0, time.time(), 0.0
    stats = "-"
    print("English-only crawler running — Ctrl+C to stop & save")
    try:
        for line in proc.stdout:
            if line.startswith("RESULT\t"):
                p = line.rstrip("\n").split("\t", 2)
                if len(p) >= 2 and p[1]:
                    batch.append((p[1], p[2] if len(p) > 2 else ""))
                if len(batch) >= BATCH:
                    new += db.insert_sites_batch(batch); batch = []
            elif line.startswith("STATS\t"):
                stats = line.rstrip("\n").split("\t")
            now = time.time()
            if now - last_ui >= 0.5:
                last_ui = now
                s = stats if isinstance(stats, list) and len(stats) > 8 else None
                extra = f" | live {s[2]} queued {s[3]} non-English {s[8]}" if s else ""
                print(f"\rnew {new:,} in {now - t0:,.0f}s ({new / max(now - t0, 1):,.0f}/s) | "
                      f"db {total + new:,} | {db.db_size_bytes() / 1e9:.2f} GB{extra}   ", end="", flush=True)
            if total + new >= TARGET_LIMIT or db.db_size_bytes() >= db.MAX_DB_BYTES * 0.98:
                print("\nTarget/storage budget reached."); break
    except KeyboardInterrupt:
        pass
    finally:
        proc.terminate()
        if batch:
            new += db.insert_sites_batch(batch)
        print(f"\nSaved. {db.get_total_in_db():,} sites in crawler.db")


if __name__ == "__main__":
    main()
