#!/usr/bin/env python3
"""Compact SQLite storage for WebCrawler — sized for 100M sites in < 10 GB.

One table, one index (the PRIMARY KEY itself):
    sites(domain TEXT PRIMARY KEY, title TEXT) WITHOUT ROWID
No status/size/letter columns (they were constants) and no secondary indexes.
The A-Z letter filter is a range scan on the primary key. Per-letter counts are
kept in a tiny `counts` table so totals never need COUNT(*) over 100M rows.
Paging is keyset-based (domain > last) so page 200,000 is as fast as page 1.
"""
import html
import os
import re
import sqlite3
import threading
import time
from typing import Dict, Iterable, List, Optional, Tuple

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "crawler.db")
MAX_DB_BYTES = 10 * 1024 ** 3        # hard storage budget
TITLE_MAX = 40                       # chars kept per title
LETTERS = [chr(c) for c in range(ord("a"), ord("z") + 1)]

_local = threading.local()
_gen = 0
_gen_lock = threading.Lock()
_ws = re.compile(r"\s+")


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=60.0, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=15000")
    conn.execute("PRAGMA cache_size=-262144")        # 256 MB page cache
    conn.execute("PRAGMA mmap_size=2147483648")      # 2 GB mmap (virtual)
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA journal_size_limit=67108864")
    conn.execute("PRAGMA wal_autocheckpoint=4000")
    return conn


def get_connection() -> sqlite3.Connection:
    """Per-thread connection; transparently reopened after delete_all_data()."""
    c = getattr(_local, "conn", None)
    if c is not None and getattr(_local, "gen", -1) != _gen:
        try:
            c.close()
        except Exception:
            pass
        c = None
    if c is None:
        c = _connect()
        _local.conn, _local.gen = c, _gen
    return c


def init_db() -> None:
    conn = get_connection()
    with conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS sites (
                            domain TEXT PRIMARY KEY,
                            title  TEXT NOT NULL
                        ) WITHOUT ROWID""")
        conn.execute("""CREATE TABLE IF NOT EXISTS counts (
                            letter TEXT PRIMARY KEY, n INTEGER NOT NULL
                        ) WITHOUT ROWID""")


# ---------------------------------------------------------------- cleaning
def clean_title(title: str) -> str:
    t = html.unescape(title or "")
    t = _ws.sub(" ", "".join(ch for ch in t if ch.isprintable() or ch.isspace())).strip()
    if len(t) > TITLE_MAX:
        t = t[:TITLE_MAX].rstrip()
    return t or "-"


def title_is_english(title: str) -> bool:
    """Second line of defence behind the engine's filter."""
    letters = [ch for ch in title if ch.isalpha()]
    if not letters:
        return True
    ascii_letters = sum(1 for ch in letters if ch.isascii())
    return ascii_letters * 100 >= 85 * len(letters)


def _bucket(domain: str) -> str:
    return domain[0] if "a" <= domain[0] <= "z" else "#"


# ------------------------------------------------------------------ writes
def insert_sites_batch(records: Iterable[Tuple[str, str]]) -> int:
    """Insert (domain, title) pairs. Returns number of NEW rows."""
    by_bucket: Dict[str, List[Tuple[str, str]]] = {}
    for d, t in records:
        d = (d or "").strip().lower()
        if not d or "example" in d or "localhost" in d or not title_is_english(t or ""):
            continue
        by_bucket.setdefault(_bucket(d), []).append((d, clean_title(t)))
    if not by_bucket:
        return 0
    conn = get_connection()
    added_total = 0
    with conn:
        for b, rows in by_bucket.items():
            before = conn.total_changes
            conn.executemany("INSERT OR IGNORE INTO sites(domain,title) VALUES(?,?)", rows)
            added = conn.total_changes - before
            if added:
                conn.execute("INSERT INTO counts(letter,n) VALUES(?,?) "
                             "ON CONFLICT(letter) DO UPDATE SET n=n+excluded.n", (b, added))
                added_total += added
    return added_total


def delete_all_data() -> None:
    """Remove every crawled site and reclaim ALL disk space (deletes the db files)."""
    global _gen
    with _gen_lock:
        _gen += 1                                   # other threads reconnect lazily
        c = getattr(_local, "conn", None)
        if c is not None:
            try:
                c.close()
            except Exception:
                pass
            _local.conn = None
        for suffix in ("", "-wal", "-shm", "-journal"):
            try:
                os.remove(DB_PATH + suffix)
            except FileNotFoundError:
                pass
        for f in ("discovered_sites.csv", "websites_A_to_Z.txt", "discovered_sites_A_to_Z.csv"):
            try:
                os.remove(os.path.join(APP_DIR, f))
            except FileNotFoundError:
                pass
    init_db()


# ------------------------------------------------------------------- reads
def get_total_in_db() -> int:
    return sum(get_letter_counts().values())


def get_letter_counts() -> Dict[str, int]:
    return {r[0]: r[1] for r in get_connection().execute("SELECT letter,n FROM counts")}


def db_size_bytes() -> int:
    return sum(os.path.getsize(DB_PATH + s) for s in ("", "-wal")
               if os.path.exists(DB_PATH + s))


def _range(letter: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
    """[lo, hi) key range for a letter filter."""
    if not letter or letter.upper() == "ALL":
        return None, None
    if letter == "#":
        return None, "a"
    l = letter.lower()
    return l, chr(ord(l) + 1)


def _prefix_hi(p: str) -> str:
    return p[:-1] + chr(ord(p[-1]) + 1)


def query_page(direction: str = "first", anchor: Optional[str] = None, limit: int = 500,
               letter: Optional[str] = None, search: str = "", contains: bool = False,
               descending: bool = False, scan_cap: int = 3_000_000
               ) -> Tuple[List[Tuple[str, str]], bool, float]:
    """Keyset pagination.
    direction: first | last | next | prev  (relative to `anchor` = edge domain of the shown page)
    Returns (rows in display order, has_more_in_direction, seconds)."""
    t0 = time.perf_counter()
    lo, hi = _range(letter)
    s = (search or "").strip().lower()
    if s and not contains:                           # instant prefix search on the PK
        lo = max(lo, s) if lo else s
        ph = _prefix_hi(s)
        hi = min(hi, ph) if hi else ph
    conds, params = [], []
    if lo is not None:
        conds.append("domain >= ?"); params.append(lo)
    if hi is not None:
        conds.append("domain < ?"); params.append(hi)
    if s and contains:
        like = "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        conds.append("(domain LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\')")
        params += [like, like]

    # forward = ascending key order; 'desc' view just flips which end is "first"
    fwd = (direction in ("first", "next")) != descending
    if direction in ("next", "prev") and anchor is not None:
        conds.append(("domain > ?" if fwd else "domain < ?")); params.append(anchor)
    where = ("WHERE " + " AND ".join(conds)) if conds else ""
    order = "ASC" if fwd else "DESC"
    sql = f"SELECT domain,title FROM sites {where} ORDER BY domain {order} LIMIT ?"
    conn = get_connection()
    rows = conn.execute(sql, params + [limit + 1]).fetchall()
    more = len(rows) > limit
    rows = rows[:limit]
    if not fwd:
        rows.reverse()
    if descending:
        rows.reverse()
    return rows, more, time.perf_counter() - t0


def match_count(letter: Optional[str], search: str, contains: bool) -> Optional[int]:
    """Cheap total: exact from counts when unfiltered/letter-only, else None."""
    if (search or "").strip():
        return None
    c = get_letter_counts()
    if not letter or letter.upper() == "ALL":
        return sum(c.values())
    return c.get("#" if letter == "#" else letter.lower(), 0)


# ----------------------------------------------------------------- exports
def export_csv(path: str) -> int:
    """Stream all sites A-Z to CSV without loading them into RAM."""
    n = 0
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write("domain,title\n")
        for d, t in get_connection().execute("SELECT domain,title FROM sites ORDER BY domain"):
            f.write(f'{d},"{t.replace(chr(34), chr(34) * 2)}"\n')
            n += 1
    os.replace(tmp, path)
    return n


def export_a_to_z(path: Optional[str] = None) -> str:
    path = path or os.path.join(APP_DIR, "websites_A_to_Z.txt")
    counts = get_letter_counts()
    tmp = path + ".tmp"
    cur_letter = None
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(f"WEBSITES FOUND: {sum(counts.values()):,}   (domain : title)   grouped A-Z\n")
        f.write("=" * 60 + "\n")
        for d, t in get_connection().execute("SELECT domain,title FROM sites ORDER BY domain"):
            b = _bucket(d)
            if b != cur_letter:
                cur_letter = b
                f.write(f"\n###  {b.upper()}  ({counts.get(b, 0):,} sites)\n")
            f.write(f"{d} : {t}\n")
    os.replace(tmp, path)
    return path


if __name__ == "__main__":
    init_db()
    print(f"DB ready. Sites: {get_total_in_db():,}")
