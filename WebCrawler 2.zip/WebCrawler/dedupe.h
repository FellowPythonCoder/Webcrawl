/* dedupe.h — fixed-memory "have I seen this domain?" filter.
 *
 * The old engine kept every visited domain string on the heap and stopped
 * discovering new domains once its 16M-entry table was half full. A Bloom
 * filter needs no per-domain memory, never fills up, and at 2^32 bits (512 MB
 * of lazily-committed zero pages) stays under ~2% false positives even after
 * 500 million probes. A false positive just means one domain is skipped.
 * Exact cross-session dedupe is done by the SQLite PRIMARY KEY.
 */
#ifndef DEDUPE_H
#define DEDUPE_H

#include <stdint.h>
#include <stdlib.h>

#define BLOOM_LOG2_BITS 32
#define BLOOM_WORDS (1ULL << (BLOOM_LOG2_BITS - 6))
#define BLOOM_MASK ((1ULL << BLOOM_LOG2_BITS) - 1)
#define BLOOM_K 4

static uint64_t *bloom_bits;

static int bloom_init(void) {
  bloom_bits = (uint64_t *)calloc((size_t)BLOOM_WORDS, sizeof(uint64_t));
  return bloom_bits != NULL;
}

static uint64_t dd_fnv(const char *s) {
  uint64_t h = 1469598103934665603ULL;
  while (*s) {
    h ^= (unsigned char)*s++;
    h *= 1099511628211ULL;
  }
  return h;
}

static uint64_t dd_mix(uint64_t x) { /* splitmix64 finaliser */
  x += 0x9e3779b97f4a7c15ULL;
  x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
  x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
  return x ^ (x >> 31);
}

/* returns 1 if the key was (probably) already present, 0 if newly inserted */
static int bloom_test_and_set(const char *key) {
  uint64_t h = dd_fnv(key);
  uint64_t h1 = dd_mix(h);
  uint64_t h2 = dd_mix(h ^ 0xa5a5a5a5deadbeefULL) | 1ULL;
  int seen = 1;
  for (int k = 0; k < BLOOM_K; k++) {
    uint64_t idx = (h1 + (uint64_t)k * h2) & BLOOM_MASK;
    uint64_t *w = &bloom_bits[idx >> 6];
    uint64_t bit = 1ULL << (idx & 63);
    if (!(*w & bit)) {
      seen = 0;
      *w |= bit;
    }
  }
  return seen;
}

#endif
