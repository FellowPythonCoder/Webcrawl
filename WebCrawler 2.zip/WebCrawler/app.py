#!/usr/bin/env python3
"""WebCrawler Pro — desktop UI for the C crawler engine (English-only, 100M-scale).

CRAWL tab   : live speed gauge vs the 1,000/s target, DB + storage meters
              (projected size at 100M sites), stat cards, rate graph, live feed.
WEBSITES tab: keyset-paged A-Z browser that stays instant at 100M rows, instant
              prefix search (optional "contains"), letter filter with counts, Z->A,
              page size, right-click menu, Delete-all-data, streamed CSV export.
"""
import collections
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
import webbrowser
from datetime import timedelta
from tkinter import filedialog, messagebox, ttk
from typing import Callable, Dict, List, Optional, Tuple

import db

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ENGINE_BIN = os.path.join(APP_DIR, "crawler_engine")
ENGINE_SRC = [os.path.join(APP_DIR, f) for f in ("crawler.c", "english.h", "dedupe.h")]

TARGET_RATE = 1000.0            # results / second
TARGET_SITES = 100_000_000
MAX_BYTES = db.MAX_DB_BYTES

BG, CARD, CARD_HI, BORDER = "#0b0e14", "#131824", "#1c2333", "#252e42"
TXT, MUTED, ACCENT = "#eef3fb", "#8794ab", "#5aa9ff"
GREEN, GREEN_D = "#3fd07a", "#1f8f4e"
RED, RED_D = "#ff5d5d", "#c93c3c"
ORANGE, PURPLE, CYAN, TRACK = "#f0b13a", "#b794ff", "#38d1e0", "#1d2536"
F_UI, F_MONO = "Helvetica Neue", "Menlo"


def fmt_bytes(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.2f} {unit}" if unit == "GB" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.2f} GB"


def fmt_short(n: float) -> str:
    for div, s in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if n >= div:
            return f"{n / div:.1f}{s}"
    return f"{int(n)}"


class FlatButton(tk.Label):
    """Label-based button: honours colours on macOS (native tk.Button ignores them)."""

    def __init__(self, parent, text, command: Callable, bg=CARD_HI, fg=TXT, hover=None,
                 font=(F_UI, 11, "bold"), padx=14, pady=6):
        super().__init__(parent, text=text, bg=bg, fg=fg, font=font, padx=padx, pady=pady, cursor="hand2")
        self._bg, self._fg, self._hover, self._cmd, self._on = bg, fg, hover or BORDER, command, True
        self.bind("<Enter>", lambda e: self._on and self.configure(bg=self._hover))
        self.bind("<Leave>", lambda e: self.configure(bg=self._bg))
        self.bind("<Button-1>", lambda e: self._on and self._cmd())

    def set_enabled(self, on: bool, bg: Optional[str] = None, fg: Optional[str] = None):
        self._on = on
        self._bg = bg or self._bg
        self.configure(bg=self._bg, fg=fg or (self._fg if on else MUTED), cursor="hand2" if on else "arrow")

    def set_style(self, bg, fg=TXT, hover=None):
        self._bg, self._fg, self._hover = bg, fg, hover or self._hover
        self.configure(bg=bg, fg=fg)


class Meter(tk.Canvas):
    def __init__(self, parent, color=GREEN, height=8, bg=CARD):
        super().__init__(parent, height=height, bg=bg, highlightthickness=0)
        self.color, self.frac = color, 0.0
        self.bind("<Configure>", lambda e: self.set(self.frac, self.color))

    def set(self, frac: float, color: Optional[str] = None):
        self.frac, self.color = max(0.0, min(1.0, frac)), color or self.color
        w, h = self.winfo_width(), int(self["height"])
        self.delete("all")
        self.create_rectangle(0, 0, w, h, fill=TRACK, outline="")
        if self.frac > 0:
            self.create_rectangle(0, 0, max(2, w * self.frac), h, fill=self.color, outline="")


class CrawlerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("WebCrawler Pro — English-only A-Z Crawler")
        self.geometry("1240x860")
        self.minsize(1040, 720)
        self.configure(bg=BG)
        db.init_db()

        # engine / run state
        self.proc: Optional[subprocess.Popen] = None
        self.run_id = 0
        self.is_running = False
        self.start_time = 0.0
        self.stats = dict(found=0, live=0, queued=0, failed=0, skipped=0, probed=0, nonen=0)
        self.stat_new = 0
        self.stat_in_db = db.get_total_in_db()
        self.rate = 0.0
        self.rate_hist: List[float] = [0.0] * 120
        self._last_found, self._last_t = 0, time.time()
        self.db_bytes = db.db_size_bytes()
        self._last_size_poll = 0.0

        # queues
        self.msg_q: "queue.Queue[Tuple[int, str]]" = queue.Queue()
        self.ui_q: "queue.Queue[Callable]" = queue.Queue()
        self.write_q: "queue.Queue[Optional[Tuple[str, str]]]" = queue.Queue()
        self.feed = collections.deque(maxlen=80)
        self.feed_dirty = False
        self._cache: Dict[object, str] = {}

        # websites-tab state
        self.page_size = 500
        self.letter = "ALL"
        self.descending = False
        self.page_no = 1
        self.total_pages: Optional[int] = None
        self.first_key = self.last_key = None
        self.has_prev = self.has_next = False
        self._qtoken = 0
        self._search_job = None
        self._total_at_load = 0

        self._styles()
        self._header()
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill=tk.BOTH, expand=True, padx=20, pady=(4, 16))
        self.tab_crawl = tk.Frame(self.nb, bg=BG)
        self.tab_web = tk.Frame(self.nb, bg=BG)
        self.nb.add(self.tab_crawl, text="  CRAWL  ")
        self.nb.add(self.tab_web, text="  WEBSITES  ")
        self._build_crawl()
        self._build_web()

        threading.Thread(target=self._writer_loop, daemon=True).start()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind_all("<Command-f>", lambda e: self._focus_search())
        self.bind_all("<Control-f>", lambda e: self._focus_search())
        self.after(50, self._pump)
        self.after(250, self._heartbeat)
        self.load_page("first")

    # ------------------------------------------------------------ styling
    def _styles(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", background=BG, foreground=TXT, font=(F_UI, 11))
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background=CARD, foreground=MUTED, padding=[26, 10], font=(F_UI, 12, "bold"))
        s.map("TNotebook.Tab", background=[("selected", BORDER)], foreground=[("selected", TXT)])
        s.configure("Treeview", background=CARD, foreground=TXT, fieldbackground=CARD, rowheight=26,
                    font=(F_UI, 11), borderwidth=0)
        s.configure("Treeview.Heading", background=BORDER, foreground=TXT, font=(F_UI, 11, "bold"), relief="flat")
        s.map("Treeview", background=[("selected", "#2b6fe6")], foreground=[("selected", "#fff")])
        s.configure("TCombobox", fieldbackground=CARD_HI, background=CARD_HI, foreground=TXT, arrowcolor=TXT)
        s.configure("Vertical.TScrollbar", background=BORDER, troughcolor=CARD, arrowcolor=MUTED, borderwidth=0)

    def _header(self):
        h = tk.Frame(self, bg=BG)
        h.pack(fill=tk.X, padx=22, pady=(14, 6))
        left = tk.Frame(h, bg=BG)
        left.pack(side=tk.LEFT)
        self.led = tk.Canvas(left, width=18, height=18, bg=BG, highlightthickness=0)
        self.led.pack(side=tk.LEFT, padx=(0, 10))
        self.led_dot = self.led.create_oval(3, 3, 15, 15, fill=RED, outline="")
        tk.Label(left, text="WEBCRAWLER PRO", bg=BG, fg=TXT, font=(F_UI, 18, "bold")).pack(side=tk.LEFT)
        self.badge = tk.Label(left, text="STOPPED", bg="#3a1d1d", fg=RED, font=(F_UI, 9, "bold"), padx=10, pady=3)
        self.badge.pack(side=tk.LEFT, padx=12)
        tk.Label(left, text="English only", bg="#12283f", fg=ACCENT, font=(F_UI, 9, "bold"), padx=10, pady=3).pack(side=tk.LEFT)
        right = tk.Frame(h, bg=BG)
        right.pack(side=tk.RIGHT)
        self.btn_start = FlatButton(right, "▶  START", self.start_crawler, bg=GREEN_D, hover=GREEN)
        self.btn_start.pack(side=tk.LEFT, padx=4)
        self.btn_stop = FlatButton(right, "■  STOP", self.stop_crawler, bg=CARD_HI)
        self.btn_stop.pack(side=tk.LEFT, padx=4)
        self.btn_stop.set_enabled(False)
        FlatButton(right, "QUIT", self.on_quit, bg="#3a2226", fg=RED, hover=RED_D).pack(side=tk.LEFT, padx=4)

    # -------------------------------------------------------- CRAWL tab
    def _card(self, parent, title, color, big=False, expand=True):
        f = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        f.pack(side=tk.LEFT, fill=tk.BOTH, expand=expand, padx=5)
        tk.Label(f, text=title, bg=CARD, fg=MUTED, font=(F_UI, 9, "bold")).pack(anchor="w", padx=14, pady=(10, 0))
        v = tk.Label(f, text="0", bg=CARD, fg=color, font=(F_UI, 30 if big else 17, "bold"))
        v.pack(anchor="w", padx=14, pady=(0, 2 if big else 10))
        return f, v

    def _build_crawl(self):
        p = self.tab_crawl
        hero = tk.Frame(p, bg=BG)
        hero.pack(fill=tk.X, pady=(10, 8))
        # speed
        f, self.v_speed = self._card(hero, "SPEED  (results / second)", CYAN, big=True)
        self.m_speed = Meter(f, CYAN); self.m_speed.pack(fill=tk.X, padx=14, pady=(0, 4))
        self.l_speed = tk.Label(f, text="target 1,000 / s", bg=CARD, fg=MUTED, font=(F_UI, 9)); self.l_speed.pack(anchor="w", padx=14, pady=(0, 10))
        # in db
        f, self.v_db = self._card(hero, "SITES IN DATABASE", GREEN, big=True)
        self.m_db = Meter(f, GREEN); self.m_db.pack(fill=tk.X, padx=14, pady=(0, 4))
        self.l_db = tk.Label(f, text="goal 100,000,000", bg=CARD, fg=MUTED, font=(F_UI, 9)); self.l_db.pack(anchor="w", padx=14, pady=(0, 10))
        # storage
        f, self.v_store = self._card(hero, "STORAGE  (budget 10 GB)", ORANGE, big=True)
        self.m_store = Meter(f, ORANGE); self.m_store.pack(fill=tk.X, padx=14, pady=(0, 4))
        self.l_store = tk.Label(f, text="projected @100M: —", bg=CARD, fg=MUTED, font=(F_UI, 9)); self.l_store.pack(anchor="w", padx=14, pady=(0, 10))

        self.small: Dict[str, tk.Label] = {}
        for row in ((("FOUND (session)", GREEN), ("NEW UNIQUE", GREEN), ("PROBED", ACCENT), ("LIVE CONNS", ORANGE), ("QUEUED", PURPLE)),
                    (("FAILED", RED), ("SKIPPED", MUTED), ("NON-ENGLISH", CYAN), ("ETA TO 100M", TXT), ("UPTIME", TXT))):
            r = tk.Frame(p, bg=BG)
            r.pack(fill=tk.X, pady=(0, 8))
            for name, col in row:
                _, v = self._card(r, name, col)
                self.small[name] = v

        mid = tk.Frame(p, bg=BG)
        mid.pack(fill=tk.BOTH, expand=True, pady=(0, 4))
        gc = tk.Frame(mid, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        gc.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(5, 8))
        gh = tk.Frame(gc, bg=CARD); gh.pack(fill=tk.X, padx=14, pady=(10, 0))
        tk.Label(gh, text="SPEED — LAST 2 MINUTES", bg=CARD, fg=MUTED, font=(F_UI, 9, "bold")).pack(side=tk.LEFT)
        self.graph = tk.Canvas(gc, bg=CARD, highlightthickness=0)
        self.graph.pack(fill=tk.BOTH, expand=True, padx=14, pady=(4, 12))
        self.graph.bind("<Configure>", lambda e: self._draw_graph())

        fc = tk.Frame(mid, bg=CARD, width=430, highlightthickness=1, highlightbackground=BORDER)
        fc.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(0, 5)); fc.pack_propagate(False)
        tk.Label(fc, text="LIVE STREAM", bg=CARD, fg=MUTED, font=(F_UI, 9, "bold")).pack(anchor="w", padx=14, pady=(10, 4))
        self.feed_box = tk.Listbox(fc, bg=CARD, fg=TXT, selectbackground=CARD_HI, highlightthickness=0,
                                   borderwidth=0, font=(F_MONO, 10), activestyle="none")
        self.feed_box.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 10))

        self.status = tk.Label(p, text="Ready. Crawls plain-HTTP sites, English pages only.", bg=BG, fg=MUTED,
                               font=(F_UI, 10), anchor="w")
        self.status.pack(fill=tk.X, padx=6, pady=(4, 0))

    def _set(self, key, widget, text, **cfg):
        if self._cache.get(key) != text:
            self._cache[key] = text
            widget.configure(text=text, **cfg)

    def _draw_graph(self):
        c = self.graph
        w, h = c.winfo_width(), c.winfo_height()
        if w < 60 or h < 40:
            return
        c.delete("all")
        pts = self.rate_hist
        top = max(max(pts) * 1.2, 20.0)
        pad_l, pad_b = 44, 16
        pw, ph = w - pad_l - 4, h - pad_b - 8
        for frac in (0.25, 0.5, 0.75, 1.0):
            y = 8 + ph * (1 - frac)
            c.create_line(pad_l, y, w - 4, y, fill="#1a2233", dash=(2, 4))
            c.create_text(pad_l - 6, y, text=fmt_short(top * frac), fill=MUTED, anchor="e", font=(F_UI, 8))
        if TARGET_RATE <= top:
            y = 8 + ph * (1 - TARGET_RATE / top)
            c.create_line(pad_l, y, w - 4, y, fill=GREEN_D, dash=(6, 4))
            c.create_text(w - 8, y - 8, text="target 1,000/s", fill=GREEN, anchor="e", font=(F_UI, 8, "bold"))
        n = len(pts)
        xy = [(pad_l + pw * i / (n - 1), 8 + ph * (1 - v / top)) for i, v in enumerate(pts)]
        c.create_polygon([pad_l, 8 + ph] + [q for pt in xy for q in pt] + [pad_l + pw, 8 + ph], fill="#0f2740", outline="")
        c.create_line([q for pt in xy for q in pt], fill=CYAN, width=2)
        c.create_oval(xy[-1][0] - 4, xy[-1][1] - 4, xy[-1][0] + 4, xy[-1][1] + 4, fill=CYAN, outline="")

    # ------------------------------------------------------- WEBSITES tab
    def _build_web(self):
        p = self.tab_web
        top = tk.Frame(p, bg=BG); top.pack(fill=tk.X, pady=(10, 6))
        sb = tk.Frame(top, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        sb.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        tk.Label(sb, text="⌕", bg=CARD, fg=MUTED, font=(F_UI, 15)).pack(side=tk.LEFT, padx=(10, 2))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._debounce_search())
        self.search = tk.Entry(sb, textvariable=self.search_var, bg=CARD, fg=TXT, insertbackground=TXT, relief="flat",
                               font=(F_UI, 12), highlightthickness=0)
        self.search.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=8)
        FlatButton(sb, "✕", lambda: self.search_var.set(""), bg=CARD, fg=MUTED, padx=10, pady=4).pack(side=tk.RIGHT, padx=4)
        self.contains_var = tk.BooleanVar(value=False)
        tk.Checkbutton(top, text="Contains (slower)", variable=self.contains_var, command=lambda: self.load_page("first"),
                       bg=BG, fg=MUTED, selectcolor=CARD, activebackground=BG, activeforeground=TXT,
                       font=(F_UI, 10), highlightthickness=0).pack(side=tk.LEFT, padx=4)
        self.btn_order = FlatButton(top, "A → Z", self.toggle_order, bg=CARD_HI, padx=12, pady=6)
        self.btn_order.pack(side=tk.LEFT, padx=4)
        tk.Label(top, text="per page", bg=BG, fg=MUTED, font=(F_UI, 10)).pack(side=tk.LEFT, padx=(10, 2))
        self.size_var = tk.StringVar(value="500")
        cb = ttk.Combobox(top, textvariable=self.size_var, values=("100", "250", "500", "1000"), width=5, state="readonly")
        cb.pack(side=tk.LEFT, padx=2)
        cb.bind("<<ComboboxSelected>>", lambda e: self._set_page_size())
        FlatButton(top, "⟳ Refresh", lambda: self.load_page("first", keep_anchor=True), bg=CARD_HI).pack(side=tk.LEFT, padx=(10, 4))
        FlatButton(top, "Export CSV", self.export_csv, bg=GREEN_D, hover=GREEN).pack(side=tk.LEFT, padx=4)
        FlatButton(top, "🗑 Delete all data", self.delete_all, bg="#3a2226", fg=RED, hover=RED_D).pack(side=tk.LEFT, padx=4)

        lf = tk.Frame(p, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        lf.pack(fill=tk.X, pady=(2, 8))
        self.lbtn: Dict[str, FlatButton] = {}
        for L in ["ALL"] + [chr(c) for c in range(65, 91)] + ["#"]:
            b = FlatButton(lf, L, lambda l=L: self.set_letter(l), bg=CARD, fg=MUTED, hover=CARD_HI,
                           font=(F_UI, 10, "bold"), padx=7, pady=5)
            b.pack(side=tk.LEFT, padx=1, pady=3)
            self.lbtn[L] = b
        self.letter_info = tk.Label(lf, text="", bg=CARD, fg=ACCENT, font=(F_UI, 10, "bold"))
        self.letter_info.pack(side=tk.RIGHT, padx=12)
        self._mark_letter()

        wrap = tk.Frame(p, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        wrap.pack(fill=tk.BOTH, expand=True)
        self.tree = ttk.Treeview(wrap, columns=("n", "domain", "title"), show="headings", selectmode="browse")
        for col, txt, w, anc in (("n", "#", 90, "e"), ("domain", "Domain", 360, "w"), ("title", "Page title", 640, "w")):
            self.tree.heading(col, text=txt, anchor="w" if anc == "w" else "e")
            self.tree.column(col, width=w, anchor=anc, stretch=(col == "title"))
        self.tree.tag_configure("odd", background="#161c2a")
        self.tree.tag_configure("even", background=CARD)
        sc = ttk.Scrollbar(wrap, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sc.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); sc.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.bind("<Double-1>", lambda e: self.open_selected())
        self.tree.bind("<Return>", lambda e: self.open_selected())
        self.tree.bind("<Prior>", lambda e: self.load_page("prev"))
        self.tree.bind("<Next>", lambda e: self.load_page("next"))
        for seq in ("<Command-c>", "<Control-c>"):
            self.tree.bind(seq, lambda e: self.copy_selected("domain"))
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Open in browser", command=self.open_selected)
        menu.add_command(label="Copy domain", command=lambda: self.copy_selected("domain"))
        menu.add_command(label="Copy URL", command=lambda: self.copy_selected("url"))
        def popup(e):
            iid = self.tree.identify_row(e.y)
            if iid:
                self.tree.selection_set(iid); menu.tk_popup(e.x_root, e.y_root)
        self.tree.bind("<Button-2>", popup); self.tree.bind("<Button-3>", popup)

        bar = tk.Frame(p, bg=BG); bar.pack(fill=tk.X, pady=(8, 0))
        self.info = tk.Label(bar, text="", bg=BG, fg=MUTED, font=(F_UI, 10)); self.info.pack(side=tk.LEFT)
        nav = tk.Frame(bar, bg=BG); nav.pack(side=tk.RIGHT)
        self.nav_btns = {}
        for key, txt in (("first", "« First"), ("prev", "‹ Prev"), ("next", "Next ›"), ("last", "Last »")):
            b = FlatButton(nav, txt, lambda k=key: self.load_page(k), bg=CARD_HI, font=(F_UI, 10, "bold"), padx=10, pady=4)
            b.pack(side=tk.LEFT, padx=2)
            self.nav_btns[key] = b
            if key == "prev":
                self.page_lbl = tk.Label(nav, text="Page 1", bg=BG, fg=CYAN, font=(F_UI, 10, "bold"), padx=10)
                self.page_lbl.pack(side=tk.LEFT)

    def _focus_search(self):
        self.nb.select(self.tab_web); self.search.focus_set(); self.search.select_range(0, tk.END)

    def _debounce_search(self):
        if self._search_job:
            self.after_cancel(self._search_job)
        self._search_job = self.after(220, lambda: self.load_page("first"))

    def _set_page_size(self):
        self.page_size = int(self.size_var.get()); self.load_page("first")

    def toggle_order(self):
        self.descending = not self.descending
        self.btn_order.configure(text="Z → A" if self.descending else "A → Z")
        self.load_page("first")

    def set_letter(self, l: str):
        self.letter = l; self._mark_letter(); self.load_page("first")

    def _mark_letter(self):
        for L, b in self.lbtn.items():
            b.set_style("#2b6fe6" if L == self.letter else CARD, "#fff" if L == self.letter else MUTED)

    def load_page(self, direction: str, keep_anchor: bool = False):
        """Async keyset page load; stale results are dropped."""
        self._qtoken += 1
        token = self._qtoken
        anchor = None
        if direction == "next":
            anchor = self.last_key
        elif direction == "prev":
            anchor = self.first_key
        if direction in ("next", "prev") and anchor is None:
            direction = "first"
        args = dict(direction=direction, anchor=anchor, limit=self.page_size,
                    letter=None if self.letter == "ALL" else self.letter, search=self.search_var.get(),
                    contains=self.contains_var.get(), descending=self.descending)
        self.info.configure(text="Loading…")

        def work():
            try:
                rows, more, secs = db.query_page(**args)
                total = db.match_count(args["letter"], args["search"], args["contains"])
                counts = db.get_letter_counts()
            except Exception as ex:  # db busy / deleted
                rows, more, secs, total, counts = [], False, 0.0, 0, {}
            self.ui_q.put(lambda: self._apply_page(token, direction, rows, more, secs, total, counts))
        threading.Thread(target=work, daemon=True).start()

    def _apply_page(self, token, direction, rows, more, secs, total, counts):
        if token != self._qtoken:
            return
        if direction == "first":
            self.page_no, self.has_prev, self.has_next = 1, False, more
        elif direction == "next":
            self.page_no += 1; self.has_prev, self.has_next = True, more
        elif direction == "prev":
            self.page_no = max(1, self.page_no - 1); self.has_next, self.has_prev = True, more
        else:  # last
            self.has_next, self.has_prev = False, more
            self.page_no = max(1, -(-total // self.page_size)) if total else 1
        self.total_pages = max(1, -(-total // self.page_size)) if total else None
        self.tree.delete(*self.tree.get_children())
        base = (self.page_no - 1) * self.page_size
        for i, (d, t) in enumerate(rows):
            self.tree.insert("", tk.END, values=(f"{base + i + 1:,}", d, t), tags=("odd" if i % 2 else "even",))
        self.first_key = rows[0][0] if rows else None
        self.last_key = rows[-1][0] if rows else None
        self._total_at_load = total or 0
        if total is not None:
            self.info.configure(text=f"{total:,} sites  ·  showing {len(rows):,}  ·  {secs * 1000:.1f} ms")
        else:
            self.info.configure(text=f"{len(rows):,} matches on this page  ·  {secs * 1000:.1f} ms"
                                     + ("  ·  more available" if self.has_next else ""))
        pg = f"Page {self.page_no:,}" + (f" of {self.total_pages:,}" if self.total_pages else "")
        self.page_lbl.configure(text=pg)
        self.nav_btns["first"].set_enabled(self.has_prev); self.nav_btns["prev"].set_enabled(self.has_prev)
        self.nav_btns["next"].set_enabled(self.has_next); self.nav_btns["last"].set_enabled(self.has_next and total is not None)
        cnt = counts.get("#" if self.letter == "#" else self.letter.lower(), None) if self.letter != "ALL" else sum(counts.values())
        self.letter_info.configure(text=f"{self.letter}: {cnt:,}" if cnt is not None else "")

    def _selected(self, col: str) -> Optional[str]:
        sel = self.tree.selection()
        if not sel:
            return None
        v = self.tree.item(sel[0], "values")
        return v[1] if col in ("domain", "url") else v[2]

    def open_selected(self):
        d = self._selected("domain")
        if d:
            webbrowser.open_new_tab(f"http://{d}")

    def copy_selected(self, what: str):
        d = self._selected("domain")
        if d:
            self.clipboard_clear(); self.clipboard_append(f"http://{d}" if what == "url" else d)

    def export_csv(self):
        path = filedialog.asksaveasfilename(initialdir=APP_DIR, initialfile="websites_A_to_Z.csv", defaultextension=".csv")
        if not path:
            return
        self.status.configure(text="Exporting… (streamed, low memory)")
        def work():
            try:
                n = db.export_csv(path); msg = f"Exported {n:,} sites → {path}"
            except Exception as ex:
                msg = f"Export failed: {ex}"
            self.ui_q.put(lambda: self.status.configure(text=msg))
        threading.Thread(target=work, daemon=True).start()

    def delete_all(self):
        if not messagebox.askyesno("Delete all data",
                                   "Permanently delete ALL crawled websites and reclaim the disk space?\n\nThis cannot be undone.",
                                   icon="warning", default="no"):
            return
        if self.is_running:
            self.stop_crawler()
        while not self.write_q.empty():
            try: self.write_q.get_nowait()
            except queue.Empty: break
        db.delete_all_data()
        self.stat_in_db = self.stat_new = 0
        self.db_bytes = db.db_size_bytes()
        self.feed.clear(); self.feed_dirty = True
        for k in self.stats: self.stats[k] = 0
        self.status.configure(text="All data deleted. Database reset to empty.")
        self.load_page("first")

    # -------------------------------------------------- engine lifecycle
    def _engine_stale(self) -> bool:
        if not os.path.exists(ENGINE_BIN):
            return True
        t = os.path.getmtime(ENGINE_BIN)
        return any(os.path.exists(s) and os.path.getmtime(s) > t for s in ENGINE_SRC)

    def start_crawler(self):
        if self.is_running:
            return
        if db.db_size_bytes() >= MAX_BYTES * 0.98:
            messagebox.showwarning("Storage budget reached", "The database is at the 10 GB budget. Export or delete data first.")
            return
        if self._engine_stale():
            self.status.configure(text="Compiling engine (clang -O3)…"); self.update_idletasks()
            r = subprocess.run(["clang", "-O3", "-pthread", os.path.join(APP_DIR, "crawler.c"), "-o", ENGINE_BIN],
                               capture_output=True, text=True)
            if r.returncode != 0:
                messagebox.showerror("Build error", (r.stderr or "clang failed. Install Xcode command line tools: xcode-select --install")[-1500:])
                return
        try:
            import resource
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            want = 20000 if hard == resource.RLIM_INFINITY else min(hard, 20000)
            if want > soft:
                resource.setrlimit(resource.RLIMIT_NOFILE, (want, hard))
        except Exception:
            pass
        try:
            self.proc = subprocess.Popen([ENGINE_BIN], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         text=True, errors="replace", bufsize=1 << 20, cwd=APP_DIR)
        except Exception as ex:
            messagebox.showerror("Launch error", str(ex)); return
        self.run_id += 1
        self.is_running, self.start_time = True, time.time()
        self._last_found, self._last_t, self.stat_new = 0, time.time(), 0
        for k in self.stats: self.stats[k] = 0
        self.led.itemconfig(self.led_dot, fill=GREEN)
        self.badge.configure(text="RUNNING", bg="#153322", fg=GREEN)
        self.btn_start.set_enabled(False, bg=CARD_HI); self.btn_stop.set_enabled(True, bg=RED_D)
        self.status.configure(text="Engine running — English-only filter on, following links from English pages.")
        threading.Thread(target=self._reader, args=(self.proc, self.run_id), daemon=True).start()

    def _reader(self, proc, rid):
        for line in proc.stdout:
            self.msg_q.put((rid, line))
        self.msg_q.put((rid, "__EXIT__"))

    def stop_crawler(self, note: str = ""):
        if not self.is_running:
            return
        self.is_running = False
        if self.proc:
            try: self.proc.terminate()
            except Exception: pass
        self.proc = None
        self.led.itemconfig(self.led_dot, fill=RED)
        self.badge.configure(text="STOPPED", bg="#3a1d1d", fg=RED)
        self.btn_start.set_enabled(True, bg=GREEN_D); self.btn_stop.set_enabled(False, bg=CARD_HI)
        self.status.configure(text=note or f"Stopped. {self.stat_in_db:,} sites saved in crawler.db.")

    def on_quit(self):
        self.stop_crawler()
        self.write_q.put(None)                      # flush + end writer
        deadline = time.time() + 5
        while self._writer_alive and time.time() < deadline:
            time.sleep(0.05)
        self.destroy(); sys.exit(0)

    # ---------------------------------------------------- writer thread
    _writer_alive = True

    def _writer_loop(self):
        batch: List[Tuple[str, str]] = []
        last = time.time()
        while True:
            try:
                item = self.write_q.get(timeout=0.3)
            except queue.Empty:
                item = "tick"
            done = item is None
            if isinstance(item, tuple):
                batch.append(item)
            if batch and (done or len(batch) >= 1000 or time.time() - last >= 0.5):
                try:
                    self.stat_new += db.insert_sites_batch(batch)
                    self.stat_in_db = db.get_total_in_db()
                except Exception:
                    pass
                batch, last = [], time.time()
            if done:
                self._writer_alive = False
                return

    # ------------------------------------------------------ UI pump
    def _pump(self):
        try:
            for _ in range(200):                    # run queued UI callbacks
                self.ui_q.get_nowait()()
        except queue.Empty:
            pass
        n = 0
        while n < 3000:
            try:
                rid, line = self.msg_q.get_nowait()
            except queue.Empty:
                break
            n += 1
            if rid != self.run_id:
                continue                            # stale line from a previous run
            if line == "__EXIT__":
                if self.is_running:
                    self.stop_crawler("Engine exited unexpectedly.")
                break
            if line.startswith("RESULT\t"):
                parts = line.rstrip("\n").split("\t", 2)
                if len(parts) >= 2 and parts[1]:
                    title = parts[2] if len(parts) > 2 else ""
                    self.write_q.put((parts[1], title))
                    self.feed.appendleft(f"{time.strftime('%H:%M:%S')}  {parts[1][:28]:<28} {title[:26]}")
                    self.feed_dirty = True
            elif line.startswith("STATS\t"):
                f = line.rstrip("\n").split("\t")
                try:
                    s = self.stats
                    s["found"], s["live"], s["queued"] = int(f[1]), int(f[2]), int(f[3]) + int(f[4])
                    s["failed"], s["skipped"], s["probed"] = int(f[5]), int(f[6]), int(f[7])
                    s["nonen"] = int(f[8]) if len(f) > 8 else 0
                except (ValueError, IndexError):
                    pass
        self.after(50, self._pump)

    def _heartbeat(self):
        now = time.time()
        if self.is_running:
            dt = now - self._last_t
            if dt >= 1.0:
                inst = (self.stats["found"] - self._last_found) / dt
                self.rate = inst if self.rate == 0 else self.rate * 0.6 + inst * 0.4
                self._last_found, self._last_t = self.stats["found"], now
                self.rate_hist.append(self.rate); self.rate_hist.pop(0)
                self._draw_graph()
        else:
            self.rate = 0.0
        if now - self._last_size_poll > 2.0:
            self._last_size_poll = now
            self.db_bytes = db.db_size_bytes()
            if self.is_running and self.db_bytes >= MAX_BYTES * 0.98:
                self.stop_crawler("Stopped: database reached the 10 GB storage budget.")

        if self.feed_dirty:
            self.feed_dirty = False
            self.feed_box.delete(0, tk.END)
            self.feed_box.insert(tk.END, *list(self.feed))

        s = self.stats
        self._set("speed", self.v_speed, f"{self.rate:,.0f} /s")
        self.m_speed.set(self.rate / TARGET_RATE, GREEN if self.rate >= TARGET_RATE else CYAN)
        self._set("speedl", self.l_speed, f"{self.rate / TARGET_RATE * 100:.0f}% of 1,000 / s target")
        n = self.stat_in_db
        self._set("db", self.v_db, f"{n:,}")
        self.m_db.set(n / TARGET_SITES)
        self._set("dbl", self.l_db, f"{n / TARGET_SITES * 100:.3f}% of 100,000,000")
        self._set("store", self.v_store, fmt_bytes(self.db_bytes))
        self.m_store.set(self.db_bytes / MAX_BYTES, RED if self.db_bytes > MAX_BYTES * 0.9 else ORANGE)
        if n >= 1000:
            per = self.db_bytes / n
            self._set("storel", self.l_store, f"{per:.0f} B/site → ≈ {fmt_bytes(per * TARGET_SITES)} at 100M")
        else:
            self._set("storel", self.l_store, "projection appears after 1,000 sites")
        eta = "—"
        if self.rate > 0 and n < TARGET_SITES:
            eta = str(timedelta(seconds=int((TARGET_SITES - n) / self.rate)))
            if len(eta) > 14: eta = eta.split(",")[0]
        up = str(timedelta(seconds=int(now - self.start_time))) if self.is_running else "0:00:00"
        for name, val in (("FOUND (session)", s["found"]), ("NEW UNIQUE", self.stat_new), ("PROBED", s["probed"]),
                          ("LIVE CONNS", s["live"]), ("QUEUED", s["queued"]), ("FAILED", s["failed"]),
                          ("SKIPPED", s["skipped"]), ("NON-ENGLISH", s["nonen"])):
            self._set(name, self.small[name], f"{val:,}")
        self._set("eta", self.small["ETA TO 100M"], eta)
        self._set("up", self.small["UPTIME"], up)
        self.after(250, self._heartbeat)


def main():
    CrawlerApp().mainloop()


if __name__ == "__main__":
    main()
